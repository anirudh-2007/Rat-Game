var rat,r1,r2;
var bg;
var sword,sword_running;




function preload(){
  r1=loadImage("rat-removebg-preview.png");
  r2=loadImage("rat2-removebg-preview.png");
  bg=loadImage("bacground.jpg");
  sword_running=loadAnimation("sword1.png","sword2.png","sword3.png","sword4.png");

}



function setup() {
  createCanvas(900,700);
  rat=createSprite(350,250,30,30);
  rat.addImage(r1);
  rat.scale=0.35;
  
  sword = createSprite(200,200,10,30);
  sword.addAnimation("running" ,sword_running);
  sword.scale=0.2;
 sword.velocityY=5;
  sword.velocityX=Math.round(random(2,10));
  
  
}

function draw() {
  background(bg);
   edges=createEdgeSprites();
  sword.bounceOff(edges);
  rat.collide(edges);
  
  rat.setCollider("circle",0,0,180);
  rat.debug=true;
  
  if(keyDown(RIGHT_ARROW)){
    rat.x=rat.x+8;
    rat.addImage(r1);
    rat.scale=0.35;
  }
  
  if(keyDown(LEFT_ARROW)){
    rat.x=rat.x-8;
    rat.addImage(r2);
    rat.scale=0.35;
  }
  
  drawSprites();
}